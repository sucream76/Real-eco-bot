import time

class Economy:
    def __init__(self):
        self.balances = {}
        self.inventories = {}
        self.shop_items = {
            "apple": {"price": 10, "description": "A tasty fruit 🍎"},
            "sword": {"price": 50, "description": "A sharp blade 🗡️"},
        }
        self.levels = {}
        self.missions = {}

    def get_balance(self, user_id):
        return self.balances.get(user_id, 100)

    def add_coins(self, user_id, amount):
        self.balances[user_id] = self.get_balance(user_id) + amount

    def remove_coins(self, user_id, amount):
        self.balances[user_id] = max(0, self.get_balance(user_id) - amount)

    def buy_item(self, user_id, item_name):
        if item_name not in self.shop_items:
            return False, "❌ Item does not exist."
        item = self.shop_items[item_name]
        if self.get_balance(user_id) < item["price"]:
            return False, "❌ Not enough coins."
        self.remove_coins(user_id, item["price"])
        self.inventories.setdefault(user_id, []).append(item_name)
        return True, f"✅ You bought {item_name}!"

    def get_inventory(self, user_id):
        return self.inventories.get(user_id, [])

    def get_shop_items(self):
        return self.shop_items

    def claim_daily(self, user_id):
        now = int(time.time())
        last_claim = self.balances.get(f"{user_id}_last_daily", 0)
        if now - last_claim >= 86400:
            self.balances[user_id] = self.get_balance(user_id) + 50
            self.balances[f"{user_id}_last_daily"] = now
            return 50, "✅ You claimed your daily reward!"
        else:
            remaining = 86400 - (now - last_claim)
            hours = remaining // 3600
            minutes = (remaining % 3600) // 60
            return 0, f"⏳ You already claimed your daily. Try again in {hours}h {minutes}m."

    def add_exp(self, user_id, amount):
        level_info = self.levels.get(user_id, {"level": 1, "exp": 0})
        level_info["exp"] += amount
        while level_info["exp"] >= level_info["level"] * 100:
            level_info["exp"] -= level_info["level"] * 100
            level_info["level"] += 1
        self.levels[user_id] = level_info

    def get_level(self, user_id):
        return self.levels.get(user_id, {"level": 1, "exp": 0})

    def use_item(self, user_id, item_name):
        inventory = self.inventories.get(user_id, [])
        if item_name not in inventory:
            return False, "❌ You don't have that item in your inventory."
        inventory.remove(item_name)
        return True, f"✨ You used {item_name}!"

    def get_leaderboard(self, top_n=5):
        sorted_users = sorted(
            {k: v for k, v in self.balances.items() if not k.endswith('_last_daily')}.items(),
            key=lambda x: x[1], reverse=True
        )
        return sorted_users[:top_n]

    def assign_mission(self, user_id):
        if user_id not in self.missions:
            self.missions[user_id] = {"task": "Earn 100 coins", "progress": 0, "goal": 100}
        return self.missions[user_id]

    def update_mission_progress(self, user_id, amount):
        if user_id in self.missions:
            self.missions[user_id]["progress"] += amount

    def get_mission(self, user_id):
        return self.missions.get(user_id, {"task": "No mission assigned", "progress": 0, "goal": 0})
