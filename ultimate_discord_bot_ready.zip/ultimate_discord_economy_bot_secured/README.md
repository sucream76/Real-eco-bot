# Ultimate Discord Economy Bot
Run `main.py` to start the bot.
