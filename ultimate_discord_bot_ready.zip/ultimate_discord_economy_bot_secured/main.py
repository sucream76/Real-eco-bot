import discord
from discord.ext import commands
from economy import Economy

TOKEN = "MTM3MDYzMjU2NjMxMDQzNjkyNA.GJf760.zBYUvO4fjyuOSEXSC1JTdVJCUHqHRyJNRCszo"

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)
economy = Economy()

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"🔁 Synced {len(synced)} slash commands.")
    except Exception as e:
        print(f"❌ Failed to sync commands: {e}")

@bot.tree.command(name="balance", description="Check your balance")
async def balance(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    bal = economy.get_balance(user_id)
    await interaction.response.send_message(f"💰 You have {bal} coins.")

@bot.tree.command(name="daily", description="Claim your daily reward")
async def daily(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    amount, msg = economy.claim_daily(user_id)
    if amount > 0:
        economy.add_exp(user_id, 10)
    await interaction.response.send_message(msg)

@bot.tree.command(name="shop", description="View items in the shop")
async def shop(interaction: discord.Interaction):
    items = economy.get_shop_items()
    message = "**🛒 Shop Items:**\n"
    for name, data in items.items():
        message += f"- {name} ({data['price']} coins): {data['description']}\n"
    await interaction.response.send_message(message)

@bot.tree.command(name="buy", description="Buy an item from the shop")
async def buy(interaction: discord.Interaction, item: str):
    user_id = str(interaction.user.id)
    success, msg = economy.buy_item(user_id, item)
    if success:
        economy.add_exp(user_id, 15)
    await interaction.response.send_message(msg)

@bot.tree.command(name="inventory", description="Check your inventory")
async def inventory(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    items = economy.get_inventory(user_id)
    if not items:
        await interaction.response.send_message("🎒 Your inventory is empty.")
    else:
        await interaction.response.send_message(f"🎒 Inventory: {', '.join(items)}")

@bot.tree.command(name="use", description="Use an item from your inventory")
async def use(interaction: discord.Interaction, item: str):
    user_id = str(interaction.user.id)
    success, msg = economy.use_item(user_id, item)
    await interaction.response.send_message(msg)

@bot.tree.command(name="leaderboard", description="Show the richest users")
async def leaderboard(interaction: discord.Interaction):
    leaders = economy.get_leaderboard()
    message = "**🏆 Leaderboard:**\n"
    for i, (uid, bal) in enumerate(leaders, start=1):
        message += f"{i}. <@{uid}> - {bal} coins\n"
    await interaction.response.send_message(message)

@bot.tree.command(name="level", description="Check your level and EXP")
async def level(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    info = economy.get_level(user_id)
    await interaction.response.send_message(f"🧬 Level {info['level']} ({info['exp']} / {info['level']*100} EXP)")

@bot.tree.command(name="mission", description="Check your mission")
async def mission(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    mission = economy.assign_mission(user_id)
    await interaction.response.send_message(f"🎯 **Mission:** {mission['task']}\n"
                                            f"📊 Progress: {mission['progress']} / {mission['goal']}\n"
                                            f"💡 Complete it by using economy commands!")

bot.run(TOKEN)
