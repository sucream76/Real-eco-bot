
from flask import Flask, render_template_string, request, redirect, session, url_for
from economy import Economy

app = Flask(__name__)
app.secret_key = 'change_this_secret_key'  # For session management
economy = Economy()

# HTML templates
login_page = '''
<!doctype html>
<title>Login</title>
<h2>Login</h2>
<form method="POST">
  <label>Password:</label><br>
  <input type="password" name="password"><br><br>
  <button type="submit">Login</button>
</form>
'''

dashboard_html = '''
<!doctype html>
<title>Bot Dashboard</title>
<h1>Discord Economy Bot Admin Panel</h1>
<a href="/logout">Logout</a><br><br>

<h2>Give Coins</h2>
<form method="POST" action="/give">
  <label>User ID:</label><br>
  <input name="user_id"><br>
  <label>Amount:</label><br>
  <input name="amount"><br>
  <button type="submit">Give</button>
</form>

<h2>Remove Coins</h2>
<form method="POST" action="/remove">
  <label>User ID:</label><br>
  <input name="user_id"><br>
  <label>Amount:</label><br>
  <input name="amount"><br>
  <button type="submit">Remove</button>
</form>

<h2>Add Item</h2>
<form method="POST" action="/add_item">
  <label>User ID:</label><br>
  <input name="user_id"><br>
  <label>Item Name:</label><br>
  <input name="item"><br>
  <button type="submit">Add Item</button>
</form>

<h2>Check Balance</h2>
<form method="GET" action="/user_balance">
  <label>User ID:</label><br>
  <input name="user_id"><br>
  <button type="submit">Check</button>
</form>
{% if balance is defined %}
<h3>Balance: {{ balance }} coins</h3>
{% endif %}
'''

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form["password"] == "admin123":  # Default password, can be customized
            session["logged_in"] = True
            return redirect("/dashboard")
    return render_template_string(login_page)

@app.route("/dashboard", methods=["GET"])
def dashboard():
    if not session.get("logged_in"):
        return redirect("/")
    balance = None
    user_id = request.args.get("user_id")
    if user_id:
        balance = economy.get_balance(user_id)
    return render_template_string(dashboard_html, balance=balance)

@app.route("/give", methods=["POST"])
def give_coins():
    if not session.get("logged_in"):
        return redirect("/")
    user_id = request.form["user_id"]
    amount = int(request.form["amount"])
    economy.add_coins(user_id, amount)
    return redirect("/dashboard")

@app.route("/remove", methods=["POST"])
def remove_coins():
    if not session.get("logged_in"):
        return redirect("/")
    user_id = request.form["user_id"]
    amount = int(request.form["amount"])
    economy.remove_coins(user_id, amount)
    return redirect("/dashboard")

@app.route("/add_item", methods=["POST"])
def add_item():
    if not session.get("logged_in"):
        return redirect("/")
    user_id = request.form["user_id"]
    item = request.form["item"]
    economy.inventories.setdefault(user_id, []).append(item)
    return redirect("/dashboard")

@app.route("/user_balance", methods=["GET"])
def user_balance():
    if not session.get("logged_in"):
        return redirect("/")
    user_id = request.args.get("user_id")
    return redirect(url_for('dashboard', user_id=user_id))

@app.route("/logout")
def logout():
    session["logged_in"] = False
    return redirect("/")

if __name__ == "__main__":
    app.run(port=5000)
